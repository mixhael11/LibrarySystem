package objects;

public enum PaymentType 
{
	DEBT, CREDIT, MOBILEWALLET, OTHER
}
