package objects;

public abstract class observer {
    protected Textbook subject;

    public abstract void update();

}