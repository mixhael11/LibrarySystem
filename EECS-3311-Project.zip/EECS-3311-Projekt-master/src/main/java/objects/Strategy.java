package objects;

public interface Strategy {
    void execute(User user, PhysicalItem item);
    
}
